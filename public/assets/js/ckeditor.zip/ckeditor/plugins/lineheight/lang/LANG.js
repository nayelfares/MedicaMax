CKEDITOR.plugins.setLang('lineheight','{LANGUAGE_CODE}', {
    title: '{LINE-HEIGHT}'
} );
